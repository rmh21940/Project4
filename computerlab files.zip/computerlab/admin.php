<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Login</title>
</head>
<body>
  <h1>Admin Login</h1>

  <!-- Display an error message if redirected with an error -->
  <?php if (isset($_GET['error'])): ?>
    <p style="color: red;">
      <?php echo htmlspecialchars($_GET['error']); ?>
    </p>
  <?php endif; ?>

  <form action="http://localhost/computerlab/api/adminLogin.php" method="POST">
    <p>
      <label for="adminName">Admin Name:</label><br />
      <input type="text" name="adminName" id="adminName" required />
    </p>
    <p>
      <label for="adminPassword">Password:</label><br />
      <input type="password" name="adminPassword" id="adminPassword" required />
    </p>
    <p>
      <button type="submit">Log In</button>
    </p>
  </form>
</body>
</html>