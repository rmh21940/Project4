<?php
// api/adminLogout.php
session_start();
require_once __DIR__ . '/../config/db.php';

if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    // Insert a 'LOG OUT' record in plain text
    $adminName = $_SESSION['adminName'] ?? 'Unknown';

    $stmt = $pdo->prepare("
        INSERT INTO LoginLogs (AdminName, LogTime, ActionType)
        VALUES (:adminName, NOW(), 'OUT')
    ");
    $stmt->execute([':adminName' => $adminName]);
}

// Destroy the session
session_unset();
session_destroy();

// Redirect to admin login page
header('Location: http://localhost/computerlab/admin.html?loggedout=1');
exit;
