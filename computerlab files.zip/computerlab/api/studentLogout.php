<?php
// api/studentLogout.php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

$studentName = trim($_POST['studentName'] ?? '');
$loginNum    = trim($_POST['loginNum'] ?? '');

if (!$studentName || !$loginNum) {
    http_response_code(400);
    echo json_encode(["error" => "Missing studentName or loginNum"]);
    exit;
}

// 1) Check if the specific LoginNum belongs to this student AND is currently 'IN'
$sql = "
    SELECT LoginNum
    FROM LoginLogs
    WHERE LoginNum = :ln
      AND StudentName = :sn
      AND ActionType = 'IN'
    LIMIT 1
";
$stmt = $pdo->prepare($sql);
$stmt->execute([
    ':ln' => $loginNum,
    ':sn' => $studentName
]);

$existing = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$existing) {
    // Means no matching 'IN' record found => can't log out
    http_response_code(400);
    echo json_encode(["error" => "No matching 'IN' session found. Are you sure the loginNum is correct?"]);
    exit;
}

// 2) If found, insert a new 'OUT' record for that student
$logout = $pdo->prepare("
    INSERT INTO LoginLogs (StudentName, LogTime, ActionType)
    VALUES (:sn, NOW(), 'OUT')
");
$logout->execute([':sn' => $studentName]);

echo json_encode(["message" => "Logout successful"]);