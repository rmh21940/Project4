<?php
// api/adminLogin.php
session_start();
require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $adminName = trim($_POST['adminName'] ?? '');
    $adminPassword = $_POST['adminPassword'] ?? '';

    if (empty($adminName) || empty($adminPassword)) {
        // Redirect or respond with error
        header('Location: http://localhost/computerlab/admin.html?error=missing_credentials');
        exit;
    }

    // 1) Fetch admin's hashed password
    $stmt = $pdo->prepare("SELECT AdminPass FROM admins WHERE AdminName = :adminName");
    $stmt->execute([':adminName' => $adminName]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        // Admin not found
        header('Location: http://localhost/computerlab/admin.html?error=invalid_credentials');
        exit;
    }

    // 2) Verify password
    if (password_verify($adminPassword, $row['AdminPass'])) {
        // Credentials valid
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['adminName'] = $adminName;

        // 3) Record 'IN' event in LoginLogs (plain text)
        $logStmt = $pdo->prepare("
            INSERT INTO LoginLogs (AdminName, LogTime, ActionType)
            VALUES (:adminName, NOW(), 'IN')
        ");
        $logStmt->execute([':adminName' => $adminName]);

        // 4) Redirect to admin dashboard
        header('Location: http://localhost/computerlab/api/adminDashboard.php');
        exit;
    } else {
        // Wrong password
        header('Location: http://localhost/computerlab/admin.html?error=invalid_credentials');
        exit;
    }
} else {
    // Not a POST request
    header('Location: http://localhost/computerlab/admin.html');
    exit;
}
