<?php
// api/adminDashboard.php
session_start();

// Check if the user is actually logged in as admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: http://localhost/computerlab/admin.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Dashboard</title>
</head>
<body>
  <h1>Welcome, 
    <?php echo htmlspecialchars($_SESSION['adminName'] ?? ''); ?>
  </h1>

  <!-- Example Admin Options -->

  <section>
    <h2>Add a New Class</h2>
    <form action="adminPanel.php" method="post">
      <input type="hidden" name="action" value="addClass" />
      <p>
        <label for="classNum">Class Number:</label><br />
        <input type="text" name="classNum" id="classNum" required />
      </p>
      <p>
        <label for="className">Class Name:</label><br />
        <input type="text" name="className" id="className" required />
      </p>
      <button type="submit">Add Class</button>
    </form>
  </section>

  <hr />

  <section>
    <h2>View Login Logs</h2>
    <form action="adminPanel.php" method="post">
      <input type="hidden" name="action" value="viewLogs" />
      <button type="submit">Show Logs</button>
    </form>
  </section>

  <hr />

  <section>
    <h2>Log Out</h2>
    <form action="adminLogout.php" method="post">
      <button type="submit">Log Out</button>
    </form>
  </section>

</body>
</html>
