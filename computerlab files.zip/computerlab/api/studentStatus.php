<?php
// api/studentStatus.php
require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $studentName = trim($_GET['studentName'] ?? '');
    if (!$studentName) {
        echo json_encode(["error" => "No name supplied"]);
        exit;
    }

    // Check if the student exists
    $existsStmt = $pdo->prepare("SELECT 1 FROM Students WHERE StudentName = :name");
    $existsStmt->execute([':name' => $studentName]);
    $studentExists = $existsStmt->rowCount() > 0;

    // Default response
    $response = [
        "studentExists" => $studentExists,
        "isLoggedIn" => false
    ];

    if ($studentExists) {
        // Check last log
        $lastLog = $pdo->prepare("
            SELECT ActionType
            FROM LoginLogs
            WHERE StudentName = :studentName
            ORDER BY LogTime DESC
            LIMIT 1
        ");
        $lastLog->execute([':studentName' => $studentName]);
        $entry = $lastLog->fetch(PDO::FETCH_ASSOC);

        if ($entry && $entry['ActionType'] === 'IN') {
            $response["isLoggedIn"] = true;
        }
    }

    echo json_encode($response);
    exit;
}
?>
