<?php
// api/studentLogin.php

require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json'); // We'll return JSON

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

$studentName = trim($_POST['studentName'] ?? '');
$classNum    = trim($_POST['classNum'] ?? '');

if (!$studentName || !$classNum) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid input: missing studentName or classNum"]);
    exit;
}

// 1) Check if student is enrolled
$check = $pdo->prepare("
    SELECT 1 
    FROM Enrollments
    WHERE StudentName = :sn 
      AND ClassNum = :cn
");
$check->execute([':sn' => $studentName, ':cn' => $classNum]);
if ($check->rowCount() === 0) {
    http_response_code(401);
    echo json_encode(["error" => "Student not enrolled in this class or not found"]);
    exit;
}

// 2) Check if student is already logged in
//    We'll just see if the last log for that name was 'IN'
$last = $pdo->prepare("
    SELECT ActionType 
    FROM LoginLogs
    WHERE StudentName = :sn
    ORDER BY LogTime DESC
    LIMIT 1
");
$last->execute([':sn' => $studentName]);
$lastEntry = $last->fetch(PDO::FETCH_ASSOC);

if ($lastEntry && $lastEntry['ActionType'] === 'IN') {
    // Log them out first
    $outStmt = $pdo->prepare("
        INSERT INTO LoginLogs (StudentName, LogTime, ActionType)
        VALUES (:sn, NOW(), 'OUT')
    ");
    $outStmt->execute([':sn' => $studentName]);

    // Return a message that they were logged out automatically
    // (But we do NOT exit, we proceed to log them in again)
    // If you prefer, you could do separate logic, but let's keep it combined
    // so the user can continue to log in again after forced logout.
}

// 3) Log them in
$inStmt = $pdo->prepare("
    INSERT INTO LoginLogs (StudentName, LogTime, ActionType)
    VALUES (:sn, NOW(), 'IN')
");
$inStmt->execute([':sn' => $studentName]);

// 4) Get the newly inserted LoginNum (auto-increment ID)
$loginNum = $pdo->lastInsertId();

// 5) Return the loginNum in the JSON response
echo json_encode([
    "message"  => "Login successful",
    "loginNum" => $loginNum
]);