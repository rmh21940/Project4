<?php
// api/adminPanel.php
session_start();
require_once __DIR__ . '/../config/db.php';

// Ensure admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: http://localhost/computerlab/admin.html');
    exit;
}

$action = $_POST['action'] ?? '';

// 1) Adding a class
if ($action === 'addClass') {
    $classNum  = $_POST['classNum']  ?? '';
    $className = $_POST['className'] ?? '';

    if ($classNum && $className) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO Classes (ClassNum, ClassName)
                VALUES (:num, :name)
            ");
            $stmt->execute([
                ':num'  => $classNum,
                ':name' => $className
            ]);
            echo "<p>Class #{$classNum} ({$className}) added successfully.</p>";
        } catch (PDOException $e) {
            echo "<p style='color:red;'>Error adding class: {$e->getMessage()}</p>";
        }
    } else {
        echo "<p style='color:red;'>Please fill out both fields (ClassNum and ClassName).</p>";
    }

// 2) Viewing logs (plain text, no decryption)
} elseif ($action === 'viewLogs') {
    try {
        // Query the logs directly, since they're stored in plain-text now
        $sql = "
            SELECT 
                LoginNum,
                StudentName,
                AdminName,
                LogTime,
                ActionType
            FROM LoginLogs
            ORDER BY LogTime DESC
        ";
        $stmt = $pdo->query($sql);
        $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo "<h2>Login Logs</h2>";
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>LoginNum</th><th>StudentName</th><th>AdminName</th><th>LogTime</th><th>ActionType</th></tr>";
        foreach ($logs as $log) {
            echo "<tr>";
            echo "<td>{$log['LoginNum']}</td>";
            echo "<td>{$log['StudentName']}</td>";
            echo "<td>{$log['AdminName']}</td>";
            echo "<td>{$log['LogTime']}</td>";
            echo "<td>{$log['ActionType']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } catch (PDOException $e) {
        echo "<p style='color:red;'>Error fetching logs: {$e->getMessage()}</p>";
    }
} else {
    echo "<p style='color:red;'>Invalid action.</p>";
}

// Provide a link back to the dashboard
echo "<p><a href='adminDashboard.php'>Back to Dashboard</a></p>";