<?php
// api/classSelection.php

require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $studentName = trim($_GET['studentName'] ?? '');

    if (!$studentName) {
        http_response_code(400);
        echo json_encode(["error" => "Missing studentName"]);
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT c.ClassNum, c.ClassName 
        FROM Enrollments e
        JOIN Classes c ON e.ClassNum = c.ClassNum
        WHERE e.StudentName = :studentName
    ");
    $stmt->execute([':studentName' => $studentName]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($results);
} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
}
