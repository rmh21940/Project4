<?php
// scripts/cleanupLogs.php
require_once __DIR__ . '/../config/db.php';

try {
    $stmt = $pdo->prepare("
        DELETE FROM LoginLogs 
        WHERE LogTime < (NOW() - INTERVAL 90 DAY)
    ");
    $stmt->execute();
    echo "Old logs deleted successfully\n";
} catch (PDOException $e) {
    echo "Error deleting old logs: " . $e->getMessage();
}
