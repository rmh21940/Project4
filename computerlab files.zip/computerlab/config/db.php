<?php
// config/db.php
$encryptionKey = 'TEAM5'; // Example only, store securely


$host = 'localhost';
$db   = 'VWLogin';
$user = 'root';
$pass = ''; // or whatever your root password is

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    // Set error mode to exception for easier debugging
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
